from components import Menu, Valida
from utilities import borrarPantalla, gotoxy
from utilities import reset_color, red_color, green_color, yellow_color, blue_color, purple_color, cyan_color
from clsJson import JsonFile
from company import Company
from customer import Cliente, RegularClient
from sales import Sale
from iCrud import ICrudCliente, cargarClientes, guardarClientes
import datetime
import time
import os
from functools import reduce
from product import Product
import math 

path, _ = os.path.split(os.path.abspath(__file__))

# Función para centrar el texto en la pantalla
def centrar_texto(texto, y):
    x = (90 - len(texto)) // 2
    gotoxy(x, y)
    print(texto)

# Función para imprimir un marco
def imprimir_marco():
    print(blue_color + "*" * 90)
    print(reset_color)

# Procesos de las Opciones del Menu Facturacion
class CrudCliente:
    def __init__(self):
        self.json_file = JsonFile(path + '/archivos/clients.json')
        self.clientes = self.json_file.read()
        self.next_id = max([c['id'] for c in self.clientes], default=0) + 1

    def guardar(self):
        self.json_file.save(self.clientes)

    def validar_cedula(self, cedula):
        if len(cedula) != 10:
            return False
        else:
            multiplicador = [2, 1, 2, 1, 2, 1, 2, 1, 2]
            ced_array = list(map(int, cedula))[0:9]
            ultimo_digito = int(cedula[9])
            resultado = []
            for i, j in zip(ced_array, multiplicador):
                if i * j < 10:
                    resultado.append(i * j)
                else:
                    resultado.append((i * j) - 9)
            return ultimo_digito == int(math.ceil(float(sum(resultado)) / 10) * 10) - sum(resultado)

    def create(self, nombre, apellido, dni):
        # Validación de DNI único
        if any(cliente['dni'] == dni for cliente in self.clientes):
            return "Error: Cliente con este DNI ya existe"

        # Validación de datos no vacíos
        if not nombre or not apellido or not dni:
            return "Error: Nombre, apellido o DNI no pueden estar vacíos"

        # Validación de formato de DNI
        if not dni.startswith('09') or not len(dni) == 10 or not self.validar_cedula(dni):
            return "Error: EL DNI fue ingresado incorrectamente."

        nuevo_cliente = {'id': self.next_id, 'nombre': nombre, 'apellido': apellido, 'dni': dni}
        self.clientes.append(nuevo_cliente)
        self.next_id += 1
        self.guardar()
        return f"Cliente creado:\n{self.format_cliente(nuevo_cliente)}"  # Se añade el formato al mensaje de éxito
    
    def update(self, id, nombre=None, apellido=None, dni=None):
        # Validación de existencia del cliente
        cliente_encontrado = False
        for cliente in self.clientes:
            if cliente['id'] == id:
                cliente_encontrado = True
                if nombre:
                    cliente['nombre'] = nombre
                if apellido:
                    cliente['apellido'] = apellido
                if dni:
                    # Validación de formato de DNI
                    if not dni.startswith('09') or not len(dni) == 10 or not self.validar_cedula(dni):
                        return "Error: EL DNI fue ingresado incorrectamente."
                    cliente['dni'] = dni
                self.guardar()
                return f"Cliente actualizado:\n{self.format_cliente(cliente)}"  # Se añade el formato al mensaje de éxito

        if not cliente_encontrado:
            return "Error: Cliente no encontrado"

    def delete(self, id):
        # Validación de existencia del cliente
        for cliente in self.clientes:
            if cliente['id'] == id:
                self.clientes.remove(cliente)
                self.guardar()
                return f"Cliente eliminado:\n{self.format_cliente(cliente)}"
        return "Error: Cliente no encontrado"

    def consult(self, id=None):
        if id:
            for cliente in self.clientes:
                if cliente['id'] == id:
                    return f"Consultando cliente:\n{self.format_cliente(cliente)}"
            return "Error: Cliente no encontrado"
        return [f"Consultando cliente:\n{self.format_cliente(cliente)}" for cliente in self.clientes]

    def format_cliente(self, cliente):
        # Formatea los datos del cliente para una presentación más estética
        id_str = f"{cliente['id']:<10}"
        nombre_str = f"{cliente['nombre']:<30}"
        apellido_str = f"{cliente['apellido']:<30}"
        dni_str = f"{cliente['dni']:<15}"

        mensaje = f"""
        
        ╔════════════════════════════════════════════╗
                ID:       {id_str}
                Nombre:   {nombre_str}
                Apellido: {apellido_str}
                DNI:      {dni_str}
        ╚════════════════════════════════════════════╝
                """
        return mensaje 
    
        
class CrudProducts:
    def __init__(self):
        self.json_file = JsonFile(path + '/archivos/products.json')
        self.productos = self.json_file.read()
        self.next_id = max((p.get('id', 0) for p in self.productos), default=0) + 1

    def guardar(self):
        self.json_file.save(self.productos)

    def create(self, descrip, preci, stock):
        # Validación de tipo de datos
        if not isinstance(preci, (int, float)) or not isinstance(stock, int):
            return "Error: El precio debe ser un número y el stock debe ser un entero."

        # Validación de valores permitidos
        if preci < 0 or stock < 0:
            return "Error: El precio y el stock deben ser valores positivos."

        # Crear un nuevo producto con un ID generado automáticamente
        nuevo_producto = {'id': self.next_id, 'descrip': descrip, 'preci': preci, 'stock': stock}

        self.productos.append(nuevo_producto)
        self.next_id += 1
        self.guardar()
        return f"Producto creado: {descrip} con ID: {self.next_id - 1}\n{self.format_producto(nuevo_producto)}"

    def update(self, id, descrip=None, preci=None, stock=None):
        # Validación de existencia
        if not any(producto['id'] == id for producto in self.productos):
            return "Error: Producto no encontrado"

        # Validación de tipo de datos
        if preci is not None and not isinstance(preci, (int, float)):
            return "Error: El precio debe ser un número."
        if stock is not None and not isinstance(stock, int):
            return "Error: El stock debe ser un entero."

        # Validación de valores permitidos
        if preci is not None and preci < 0:
            return "Error: El precio debe ser un valor positivo."
        if stock is not None and stock < 0:
            return "Error: El stock debe ser un valor positivo."

        # Actualizar un producto existente
        for producto in self.productos:
            if producto['id'] == id:
                mensaje = f"Producto actualizado: ID={id}, Descripción={descrip or 'sin cambios'}, Precio={preci or 'sin cambios'}, Stock={stock or 'sin cambios'}"
                if descrip:
                    producto['descrip'] = descrip
                if preci is not None:
                    producto['preci'] = preci
                if stock is not None:
                    producto['stock'] = stock
                    self.guardar()  
                return f"{mensaje}\n{self.format_producto(producto)}"

    def delete(self, id):
        # Validación de existencia
        if not any(producto['id'] == id for producto in self.productos):
            return "Error: Producto no encontrado"

        # Eliminar un producto por ID
        for producto in self.productos:
            if producto['id'] == id:
                self.productos.remove(producto)
                self.guardar()  
                return f"Producto eliminado: ID={id}, Descripción={producto['descrip']}"

    def consult(self, id=None):
        # Consultar un producto por ID
        if id:
            for producto in self.productos:
                if producto['id'] == id:
                    return self.format_producto(producto)
            return "Error: Producto no encontrado"

        # Muestra todos los productos
        return [self.format_producto(producto) for producto in self.productos]

    def format_producto(self, producto):
        # Formatea los datos del producto para una presentación más estética
        id_str = f"{producto['id']:<10}"
        descrip_str = f"{producto['descrip']:<50}"
        preci_str = f"{producto['preci']:<15}"
        stock_str = f"{producto['stock']:<10}"

        mensaje = f"""
        ╔════════════════════════════════════════════╗
                ID:          {id_str}
                Descripción: {descrip_str}
                Precio:      {preci_str}
                Stock:       {stock_str}
        ╚════════════════════════════════════════════╝
        """
        return mensaje
        
        
class CrudSales(ICrudCliente):
    def create(self):
        validar = Valida()
        borrarPantalla()
        print('\033c', end='')
        centrar_texto("*" * 90, 1)
        centrar_texto("Registro de Venta", 2)
        centrar_texto(Company.get_business_name(), 3)
        centrar_texto(f"Factura#:F0999999 {' ' * 3} Fecha:{datetime.datetime.now()}", 4)
        centrar_texto("Subtotal:", 4)
        centrar_texto("Decuento:", 5)
        centrar_texto("Iva     :", 6)
        centrar_texto("Total   :", 7)
        centrar_texto("Cedula:", 6)
        dni = validar.solo_numeros("Error: Solo numeros", 23, 6)
        json_file = JsonFile(path + '/clients.json')
        client = json_file.find("dni", dni)  

        if not client:
            centrar_texto("Cliente no existe", 6)
            return

        client = client[0]
        cli = RegularClient(client["nombre"], client["apellido"], client["dni"], card=True)
        sale = Sale(cli)

        centrar_texto(cli.fullName(), 6)
        centrar_texto("*" * 90, 8)
        centrar_texto("Linea", 9)
        centrar_texto("Id_Articulo", 9)
        centrar_texto("Descripcion", 9)
        centrar_texto("Precio", 9)
        centrar_texto("Cantidad", 9)
        centrar_texto("Subtotal", 9)
        centrar_texto("n->Terminar Venta)", 9)

        follow = "s"
        line = 1
        while follow.lower() == "s":
            gotoxy(7, 9 + line)
            print(line)
            gotoxy(15, 9 + line)
            id = int(validar.solo_numeros("Error: Solo numeros", 15, 9 + line))
            json_file = JsonFile(path + 'products.json')
            prods = json_file.find("id", id)
            if not prods:
                gotoxy(24, 9 + line)
                print("Producto no existe")
                time.sleep(5)
                gotoxy(24, 9 + line)
                print(" " * 20)
            else:
                prods = prods[0]
                product = Product(prods["id"], prods["descripcion"], prods["precio"], prods["stock"])
                gotoxy(24, 9 + line)
                print(product.descrip)
                gotoxy(38, 9 + line)
                print(product.preci)
                gotoxy(49, 9 + line)
                qyt = int(validar.solo_numeros("Error:Solo numeros", 49, 9 + line))
                gotoxy(59, 9 + line)
                print(product.preci * qyt)
                sale.add_detail(product, qyt)
                gotoxy(76, 4)
                print(round(sale.subtotal, 2))
                gotoxy(76, 5)
                print(round(sale.discount, 2))
                gotoxy(76, 6)
                print(round(sale.iva, 2))
                gotoxy(76, 7)
                print(round(sale.total, 2))
                gotoxy(74, 9 + line)
                follow = input() or "s"
                gotoxy(76, 9 + line)
                print("✔")
                line += 1

        gotoxy(15, 9 + line)
        print("Esta seguro de grabar la venta(s/n):")
        gotoxy(54, 9 + line)
        procesar = input().lower()
        if procesar == "s":
            gotoxy(15, 10 + line)
            print("😊 Venta Grabada satisfactoriamente 😊")
            json_file = JsonFile(path + 'invoices.json')
            invoices = json_file.read()
            ult_invoices = invoices[-1]["factura"] + 1
            data = sale.getJson()
            data["factura"] = ult_invoices
            invoices.append(data)
            json_file = JsonFile(path + 'invoices.json')
            json_file.save(invoices)
        else:
            gotoxy(20, 10 + line)
            print("🤣 Venta Cancelada 🤣")
        time.sleep(5)

    def update():
        pass

    def delete():
        pass

    def consult(self):
        print('\033c', end='')
        centrar_texto("█" * 90, 1)
        centrar_texto("██" + " " * 34 + "Consulta de Venta" + " " * 35 + "██", 2)
        centrar_texto("Ingrese Factura: ", 4)
        invoice = input("Ingrese Factura: ")
        if invoice.isdigit():
            invoice = int(invoice)
            json_file = JsonFile(path + 'invoices.json')
            invoices = json_file.find("factura", invoice)
            print(f"Impresion de la Factura#{invoice}")
            print(invoices)
        else:
            json_file = JsonFile(path + 'invoices.json')
            invoices = json_file.read()
            print("Consulta de Facturas")
            for fac in invoices:
                print(f"{fac['factura']}   {fac['Fecha']}   {fac['cliente']}   {fac['total']}")

            suma = reduce(lambda total, invoice: round(total + invoice["total"], 2),
                          invoices, 0)
            totales_map = list(map(lambda invoice: invoice["total"], invoices))
            total_client = list(filter(lambda invoice: invoice["cliente"] == "Dayanna Vera", invoices))

            max_invoice = max(totales_map)
            min_invoice = min(totales_map)
            tot_invoices = sum(totales_map)
            print("filter cliente: ", total_client)
            print(f"map Facturas:{totales_map}")
            print(f"              max Factura:{max_invoice}")
            print(f"              min Factura:{min_invoice}")
            print(f"              sum Factura:{tot_invoices}")
            print(f"              reduce Facturas:{suma}")
        x = input("presione una tecla para continuar...")

# Menu Proceso Principal
opc = ''
while opc != '4':  
    borrarPantalla()
    imprimir_marco()
    centrar_texto("Menú Facturación", 1)
    imprimir_marco()
    print("\n".join(["1) Clientes", "2) Productos", "3) Ventas", "4) Salir"]))
    opc = input("Seleccione una opción: ")

    if opc == "1":  
        opc1 = ''
        while opc1 != '5':
            borrarPantalla()
            imprimir_marco()
            centrar_texto("Menú Clientes", 1)
            imprimir_marco()
            print("\n".join(["1) Ingresar", "2) Actualizar", "3) Eliminar", "4) Consultar", "5) Salir"]))
            opc1 = input("Seleccione una opción: ")
            crud_cliente = CrudCliente()  

            if opc1 == "1":  # Ingresar cliente
                nombre = input("Ingrese el nombre del cliente: ")
                apellido = input("Ingrese el apellido del cliente: ")
                dni = input("Ingrese el DNI del cliente: ")
                print(crud_cliente.create(nombre, apellido, dni))  # Crear cliente
                time.sleep(5)
            
            elif opc1 == "2":  # Actualizar cliente
                id = int(input("Ingrese el ID del cliente a actualizar: "))
                nombre = input("Nuevo nombre del cliente : ")
                apellido = input("Nuevo apellido del cliente : ")
                dni = input("Nuevo DNI del cliente : ")
                print(crud_cliente.update(id, nombre or None, apellido or None, dni or None))
                time.sleep(5)
            
            elif opc1 == "3":  # Eliminar cliente
                id = int(input("Ingrese el ID del cliente a eliminar: "))
                print(crud_cliente.delete(id))
                time.sleep(5)

            elif opc1 == "4":  # Consultar cliente
                id = int(input("Ingrese el ID del cliente a consultar : "))
                if id:
                    print(crud_cliente.consult(id))
                else:
                    print("\n".join(crud_cliente.consult()))
                time.sleep(5)
            
            print("Regresando al menú de clientes...")

    elif opc == "2":  
        opc2 = ''
        while opc2 != '5':
            borrarPantalla()
            imprimir_marco()
            centrar_texto("Menú Productos", 1)
            imprimir_marco()
            print("\n".join(["1) Ingresar", "2) Actualizar", "3) Eliminar", "4) Consultar", "5) Salir"]))
            opc2 = input("Seleccione una opción: ")
            crud_products = CrudProducts()  

            if opc2 == "1":  # Ingresar producto
                try:
                    descrip = input("Ingrese la descripción del producto: ")
                    preci = float(input("Ingrese el precio del producto: "))
                    stock = int(input("Ingrese el stock del producto: "))
                    print(crud_products.create(descrip, preci, stock))
                    input("Presione Enter para continuar...")
                except ValueError:
                    print("Error: Entrada inválida")
                    time.sleep(5)

            elif opc2 == "2":  # Actualizar producto
                try:
                    id = int(input("Ingrese el ID del producto a actualizar: "))
                    descrip = input("Nueva descripción del producto: ")
                    preci = float(input("Nuevo precio del producto: "))
                    stock = int(input("Nuevo stock del producto: "))
                    print(crud_products.update(id, descrip or None, preci or None, stock or None))
                    input("Presione Enter para continuar...")
                except ValueError:
                    print("Error: Entrada inválida")
                    time.sleep(5)

            elif opc2 == "3":  # Eliminar producto
                try:
                    id = int(input("Ingrese el ID del producto a eliminar: "))
                    print(crud_products.delete(id))
                    input("Presione Enter para continuar...")
                except ValueError:
                    print("Error: Entrada inválida")
                    time.sleep(5)

            elif opc2 == "4":  # Consultar producto
                try:
                    id = int(input("Ingrese el ID del producto a consultar: "))
                    resultado = crud_products.consult(id) if id else "\n".join(crud_products.consult())
                    print(resultado)  # Muestra la información antes de borrar
                    input("Presione Enter para continuar...")
                except ValueError:
                    print("Error: Entrada inválida")
                    time.sleep(5) # Espera para evitar borrado prematuro
                
        print("Regresando al menú Principal...") 
        time.sleep(5)

    elif opc == "3":
        opc3 = ''
        while opc3 != '5':
            borrarPantalla()
            print(blue_color + "*" * 90)
            centrar_texto("Menú Ventas", 1)
            print(blue_color + "*" * 90)
            print(reset_color)
            print("\n".join(["1) Ingresar", "2) Actualizar", "3) Eliminar", "4) Consultar", "5) Salir"]))
            opc3 = input("Seleccione una opción: ")
            sales = CrudSales()  
            if opc3 == "1":
                sales.create()
                time.sleep(5)
            elif opc3 == "2":
                sales.consult()
                time.sleep(5)
            elif opc3 == "3":
                sales.update()
                time.sleep(5)
            elif opc3 == "4":
                sales.delete()
                time.sleep(5)
            elif opc3 == "5":
                break
            print("Regresando al menú Principal...") 
            time.sleep(5)
            
borrarPantalla()
input("Presione una tecla para salir...")
