class Cliente:
    def __init__(self, nombre, apellido, dni):
        self.nombre = nombre
        self.apellido = apellido
        self.dni = dni  

    def __str__(self):
        return f"Cliente: {self.nombre} {self.apellido} - dni: {self.dni}"
    
    @property
    def dni(self):
        # Getter para obtener el valor del atributo privado __dni
        return self.dni
    
    @dni.setter
    def dni(self, value):
        # Asegúrate de asignar al atributo privado para evitar recursión infinita
        if len(value) in (10, 13):
            self.__dni = value  # No usar 'self.dni' para evitar ciclo infinito
        else:
            self.__dni = "9999999999"  # Valor por defecto si la longitud no es válida
  
    def __str__(self):
        # Método especial para representar la clase Cliente como una cadena
        return f'Cliente: {self.nombre} {self.apellido}'  
    
    def fullName(self):
        return self.nombre + ' ' + self.apellido
    
    def show(self):
        # Método para imprimir los detalles del cliente en la consola
        print('   Nombres    Dni')
        print(f'{self.fullName()}  {self.dni}')    

class RegularClient(Cliente):
    def __init__(self, nombre="Cliente", apellido="Final", dni="9999999999", card=False):
        # Método constructor para inicializar los atributos de la clase RetailClient
        super().__init__(nombre, apellido, dni)  # Llama al constructor de la clase padre
        self.__discount = 0.10 if card else 0  # Descuento del cliente regular
            
    @property
    def discount(self):
        # Getter para obtener el valor del descuento del cliente minorista
        return self.__discount
          
    def __str__(self):
        # Método especial para representar la clase RetailClient como una cadena
        return f'Client:{self.nombre} {self.apellido} Descuento:{self.discount}'
      
    def show(self):
        # Método para imprimir los detalles del cliente minorista en la consola
        print(f'Cliente Minorista: DNI:{self.dni} Nombre:{self.nombre} {self.apellido} Descuento:{self.discount*100}%')     

    def getJson(self):
        # Método para imprimir los detalles del cliente minorista en la consola
        return {"dni":self.dni,"nombre":self.nombre,"apellido":self.apellido,"valor": self.discount}


class VipClient(Cliente):
    def __init__(self, nombre="Consumidor", apellido="Final", dni="9999999999"):
        # Método constructor para inicializar los atributos de la clase VipClient
        super().__init__(nombre, apellido, dni)  # Llama al constructor de la clase padre
        self.__limit = 10000  # Límite de crédito del cliente VIP
              
    @property
    def limit(self):
        # Getter para obtener el valor del límite de crédito del cliente VIP
        return self.__limit
    
    @limit.setter
    def limit(self, value):
        # Setter para asignar un nuevo valor al límite de crédito del cliente VIP, con validación de rango
        self.__limit = 10000 if (value < 10000 or value > 20000) else value 
  
    def __str__(self):
        # Método especial para representar la clase VipClient como una cadena
        return f'Cliente:{self.nombre} {self.apellido} Cupo: {self.limit}'
            
    def show(self):
        # Método para imprimir los detalles del cliente VIP en la consola
        print(f'Cliente Vip: DNI:{self.dni} Nombre: {self.nombre} {self.apellido} Cupo: {self.limit}')     
        
    def getJson(self):
        # Método para imprimir los detalles del cliente VIP en la consola
        return {"dni":self.dni,"nombre":self.nombre,"apellido":self.apellido,"valor": self.limit}