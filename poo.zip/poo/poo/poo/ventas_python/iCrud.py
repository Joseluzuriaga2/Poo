from abc import ABC, abstractmethod
import json

class ICrudCliente(ABC):
    @abstractmethod
    def create(self, nombre, apellido, dni):
        # Método abstracto para crear un cliente
        pass
    
    @abstractmethod
    def update(self, id, nombre=None, apellido=None, dni=None):
        # Método abstracto para actualizar un cliente por ID
        pass
    
    @abstractmethod
    def delete(self, id):
        # Método abstracto para eliminar un cliente por ID
        pass
    
    @abstractmethod
    def consult(self):
        # Método abstracto para consultar o listar todos los clientes
        pass
#metodo para cargar clientes desde un archivo json
def cargarClientes():
    try:
        with open("clients.json","r") as f:
            clientes = json.load(f)
    except FileNotFoundError:
        clientes = []
    return clientes
# Funcion para guardar los clientes en un archivo json
def guardarClientes(Clientes):
    with open("clients.json", "w") as f:
        json.dump(Clientes, f, indent=4)