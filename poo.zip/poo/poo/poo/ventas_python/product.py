import json

class Product:
    next_id = 0

    def __init__(self, id=0, descrip="Ninguno", preci=0, stock=0):
        Product.next_id += 1
        self.__id = id if id != 0 else Product.next_id
        self.descrip = descrip
        self.preci = preci
        self.__stock = stock

    @property
    def stock(self):
        return self.__stock

    def __repr__(self):
        return f'Producto:{self.__id} {self.descrip} {self.preci} {self.stock}'

    def __str__(self):
        return f'Producto:{self.__id} {self.descrip} {self.preci} {self.stock}'

# Función para cargar los productos desde un archivo JSON
def cargar_productos():
    try:
        with open("productos.json", "r") as f:
            productos = json.load(f)
    except FileNotFoundError:
        productos = []
    except json.JSONDecodeError:
        productos = []  # Si el archivo está dañado o mal formado, devuelve una lista vacía
    return productos

# Función para guardar los productos en un archivo JSON
def guardar_productos(productos):
    with open("productos.json", "w") as f:
        json.dump(productos, f, indent=4)
